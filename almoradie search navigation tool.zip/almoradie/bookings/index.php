
<?php
require '../config/db.php';
require '../includes/auth.php';
require_login('../');

$title = is_admin() ? 'Bookings' : 'My Bookings';
$base = '../';

$search = trim($_GET['search'] ?? '');

$sql = 'SELECT b.*, p.package_name,
               ua.first_name AS a_first, ua.last_name AS a_last, ua.username AS a_user,
               uu.first_name AS u_first, uu.last_name AS u_last, uu.username AS u_user
        FROM bookings b
        JOIN packages p ON p.package_id = b.package_id
        LEFT JOIN users ua ON ua.user_id = b.added_by
        LEFT JOIN users uu ON uu.user_id = b.last_updated_by';

$conditions = [];
$args = [];

// Normal users can only see their own bookings.
if (!is_admin()) {
    $conditions[] = 'b.added_by = :me';
    $args[':me'] = current_user_id();
}

// Search by booking ID, customer name, event type, or package name.
if ($search !== '') {
    $conditions[] = '(
        CAST(b.booking_id AS CHAR) LIKE :id
        OR b.customer_name LIKE :customer
        OR b.event_type LIKE :event
        OR p.package_name LIKE :package
    )';

    $term = '%' . $search . '%';

    $args[':id'] = $term;
    $args[':customer'] = $term;
    $args[':event'] = $term;
    $args[':package'] = $term;
}

if (!empty($conditions)) {
    $sql .= ' WHERE ' . implode(' AND ', $conditions);
}

$sql .= ' ORDER BY b.event_date, b.booking_id';

$stmt = $pdo->prepare($sql);
$stmt->execute($args);
$rows = $stmt->fetchAll();

$cols = is_admin() ? 9 : 7;

require '../includes/header.php';
?>

<div class="head">
    <h1><?= is_admin() ? 'Bookings <small>(Child)</small>' : 'My Bookings' ?></h1>
    <a class="btn" href="create.php">
        <?= is_admin() ? '+ Add Booking' : '+ Book Now' ?>
    </a>
</div>

<!-- Search Bar -->
<form method="get" class="search-form">
    <input
        type="text"
        name="search"
        placeholder="Search booking ID, customer, event, or package..."
        value="<?= e($search) ?>"
    >

    <div class="search-actions">
        <button class="btn" type="submit">Search</button>
        <a class="btn" href="index.php">Clear</a>
    </div>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>Event</th>
            <th>Date</th>
            <th>Package</th>

            <?php if (is_admin()): ?>
                <th>Added By</th>
                <th>Last Updated By</th>
            <?php endif; ?>

            <th>Last Updated</th>
            <th>Actions</th>
        </tr>
    </thead>

    <tbody>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td><?= (int)$r['booking_id'] ?></td>
                <td><?= e($r['customer_name']) ?></td>
                <td><?= e($r['event_type']) ?></td>
                <td><?= e($r['event_date']) ?></td>
                <td><?= e($r['package_name']) ?></td>

                <?php if (is_admin()): ?>
                    <td><?= who($r['a_first'], $r['a_last'], $r['a_user']) ?></td>
                    <td><?= who($r['u_first'], $r['u_last'], $r['u_user']) ?></td>
                <?php endif; ?>

                <td>
                    <?= $r['last_updated'] ? e($r['last_updated']) : '&mdash;' ?>
                </td>

                <td class="actions">
                    <a class="btn small" href="edit.php?id=<?= (int)$r['booking_id'] ?>">Edit</a>
                    <a class="btn small danger" href="delete.php?id=<?= (int)$r['booking_id'] ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>

        <?php if (!$rows): ?>
            <tr>
                <td colspan="<?= $cols ?>" class="empty">
                    <?= $search !== '' ? 'No matching bookings found.' : 'No bookings yet. Click "' . (is_admin() ? 'Add Booking' : 'Book Now') . '".' ?>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require '../includes/footer.php'; ?>
