<?php

function require_login(string $base = ''): void {
    if (empty($_SESSION['user'])) {
        flash('Please log in first.', 'error');
        header('Location: ' . $base . 'login.php');
        exit;
    }
}

function current_user_id(): int {
    return (int)($_SESSION['user']['id'] ?? 0);
}

function is_admin(): bool {
    return (($_SESSION['user']['role'] ?? '') === 'admin');
}

function require_admin(string $base = ''): void {
    require_login($base);
    if (!is_admin()) {
        flash('Access denied: this page is for admins only.', 'error');
        header('Location: ' . $base . 'bookings/index.php');
        exit;
    }
}
