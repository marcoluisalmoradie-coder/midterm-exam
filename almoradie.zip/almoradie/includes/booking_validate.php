<?php
// Reads + validates booking POST data. Returns [$values, $errors]. Needs $pdo.
function read_booking(PDO $pdo): array {
    $b = [
        'customer_name' => trim($_POST['customer_name'] ?? ''),
        'event_type'    => trim($_POST['event_type'] ?? ''),
        'event_date'    => trim($_POST['event_date'] ?? ''),
        'package_id'    => (int)($_POST['package_id'] ?? 0),
    ];
    $errors = [];
    if ($b['customer_name'] === '') $errors[] = 'Customer name is required.';
    if ($b['event_type'] === '')    $errors[] = 'Event type is required.';
    $d = DateTime::createFromFormat('Y-m-d', $b['event_date']);
    if (!$d || $d->format('Y-m-d') !== $b['event_date']) $errors[] = 'Enter a valid event date.';
    $chk = $pdo->prepare('SELECT COUNT(*) FROM packages WHERE package_id = :id');
    $chk->execute([':id' => $b['package_id']]);
    if (!$chk->fetchColumn()) $errors[] = 'Please choose a valid package.';
    return [$b, $errors];
}
