<?php
// Shared form for bookings. Expects $b (array of values), $packages, $button
?>
<form method="post" class="form">
  <label>Customer Name <input name="customer_name" value="<?= e($b['customer_name']) ?>" required></label>
  <label>Event Type
    <input name="event_type" value="<?= e($b['event_type']) ?>" list="events" placeholder="Birthday, Wedding, Corporate..." required>
    <datalist id="events"><option>Birthday</option><option>Wedding</option><option>Corporate</option><option>Debut</option><option>Christening</option></datalist>
  </label>
  <label>Event Date <input name="event_date" type="date" value="<?= e($b['event_date']) ?>" required></label>
  <label>Package
    <select name="package_id" required>
      <option value="">-- Select package --</option>
      <?php foreach ($packages as $p): ?>
        <option value="<?= (int)$p['package_id'] ?>" <?= $b['package_id'] == $p['package_id'] ? 'selected' : '' ?>>
          <?= e($p['package_name']) ?> (&#8369;<?= number_format($p['package_price'], 2) ?>)
        </option>
      <?php endforeach; ?>
    </select>
  </label>
  <div><button class="btn" type="submit"><?= e($button) ?></button> <a class="btn ghost" href="index.php">Cancel</a></div>
</form>
