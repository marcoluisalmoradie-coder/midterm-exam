<?php
// $base = path prefix to project root ('' or '../'), $title = page title
// $public = true on login/register pages (hides the menu)
$base   = $base   ?? '';
$title  = $title  ?? 'FlashFrame';
$public = $public ?? false;
$user   = current_user();
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | FlashFrame Photobooth</title>
<link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>
<body>
<header class="topbar">
  <div class="brand">&#128247; FlashFrame <span>Photobooth System</span></div>
  <?php if (!$public && $user): ?>
  <nav>
    <?php if (is_admin()): ?>
      <a href="<?= $base ?>index.php">Dashboard</a>
      <a href="<?= $base ?>packages/index.php">Packages</a>
      <a href="<?= $base ?>bookings/index.php">Bookings</a>
    <?php else: ?>
      <a href="<?= $base ?>bookings/index.php">My Bookings</a>
      <a href="<?= $base ?>bookings/create.php">Book Now</a>
    <?php endif; ?>
    <span class="whoami"><span class="role <?= is_admin() ? 'admin' : 'user' ?>"><?= is_admin() ? 'Admin' : 'User' ?></span>
      <strong><?= e($user['name']) ?></strong> (@<?= e($user['username']) ?>)</span>
    <a class="logout" href="<?= $base ?>logout.php">Logout</a>
  </nav>
  <?php endif; ?>
</header>
<main class="container">
<?php flash_show(); ?>
