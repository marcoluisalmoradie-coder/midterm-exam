CREATE DATABASE IF NOT EXISTS photobooth_db;
USE photobooth_db;


CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    address VARCHAR(150) NOT NULL,
    age INT NOT NULL,
    username VARCHAR(30) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','user') NOT NULL DEFAULT 'user',
    date_registered DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (first_name, last_name, address, age, username, password_hash, role)
VALUES ('System', 'Admin', 'FlashFrame HQ', 30, 'admin', '$2y$10$9HvO7/atEy7G3SAsewCnZer5208d9Ymqzkj2A886quV45tntktDoC', 'admin');

CREATE TABLE IF NOT EXISTS packages (
    package_id INT AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(100) NOT NULL,
    package_price DECIMAL(10,2) NOT NULL,
    package_description VARCHAR(255),
    added_by INT NULL,
    last_updated_by INT NULL,
    last_updated DATETIME NULL,

    FOREIGN KEY (added_by) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (last_updated_by) REFERENCES users(user_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    event_date DATE NOT NULL,
    package_id INT NOT NULL,
    added_by INT NULL,
    last_updated_by INT NULL,
    last_updated DATETIME NULL,

    FOREIGN KEY (package_id)
    REFERENCES packages(package_id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT,

    FOREIGN KEY (added_by) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (last_updated_by) REFERENCES users(user_id) ON DELETE SET NULL
);


