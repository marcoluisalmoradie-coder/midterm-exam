<?php
require '../config/db.php';
require '../includes/auth.php';
require_login('../');
$title = is_admin() ? 'Bookings' : 'My Bookings'; $base = '../';
require '../includes/header.php';

$sql = 'SELECT b.*, p.package_name,
               ua.first_name AS a_first, ua.last_name AS a_last, ua.username AS a_user,
               uu.first_name AS u_first, uu.last_name AS u_last, uu.username AS u_user
        FROM bookings b
        JOIN packages p ON p.package_id = b.package_id
        LEFT JOIN users ua ON ua.user_id = b.added_by
        LEFT JOIN users uu ON uu.user_id = b.last_updated_by';
$args = [];
if (!is_admin()) {                       // normal users only see their own bookings
    $sql .= ' WHERE b.added_by = :me';
    $args[':me'] = current_user_id();
}
$sql .= ' ORDER BY b.event_date, b.booking_id';
$stmt = $pdo->prepare($sql);
$stmt->execute($args);
$rows = $stmt->fetchAll();
$cols = is_admin() ? 9 : 7;
?>
<div class="head"><h1><?= is_admin() ? 'Bookings <small>(Child)</small>' : 'My Bookings' ?></h1>
  <a class="btn" href="create.php"><?= is_admin() ? '+ Add Booking' : '+ Book Now' ?></a></div>
<table>
  <thead><tr><th>ID</th><th>Customer</th><th>Event</th><th>Date</th><th>Package</th>
             <?php if (is_admin()): ?><th>Added By</th><th>Last Updated By</th><?php endif; ?>
             <th>Last Updated</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= (int)$r['booking_id'] ?></td>
      <td><?= e($r['customer_name']) ?></td>
      <td><?= e($r['event_type']) ?></td>
      <td><?= e($r['event_date']) ?></td>
      <td><?= e($r['package_name']) ?></td>
      <?php if (is_admin()): ?>
        <td><?= who($r['a_first'], $r['a_last'], $r['a_user']) ?></td>
        <td><?= who($r['u_first'], $r['u_last'], $r['u_user']) ?></td>
      <?php endif; ?>
      <td><?= $r['last_updated'] ? e($r['last_updated']) : '&mdash;' ?></td>
      <td class="actions">
        <a class="btn small" href="edit.php?id=<?= (int)$r['booking_id'] ?>">Edit</a>
        <a class="btn small danger" href="delete.php?id=<?= (int)$r['booking_id'] ?>">Delete</a>
      </td>
    </tr>
  <?php endforeach; if (!$rows): ?>
    <tr><td colspan="<?= $cols ?>" class="empty">No bookings yet. Click "<?= is_admin() ? 'Add Booking' : 'Book Now' ?>".</td></tr>
  <?php endif; ?>
  </tbody>
</table>
<?php require '../includes/footer.php'; ?>
