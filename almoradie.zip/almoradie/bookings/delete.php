<?php
require '../config/db.php';
require '../includes/auth.php';
require_login('../');
$title = 'Delete Booking'; $base = '../';
$id = (int)($_GET['id'] ?? $_POST['booking_id'] ?? 0);

$sql = 'SELECT b.*, p.package_name FROM bookings b JOIN packages p ON p.package_id = b.package_id WHERE b.booking_id = :id';
$args = [':id' => $id];
if (!is_admin()) { $sql .= ' AND b.added_by = :me'; $args[':me'] = current_user_id(); }   // users: own bookings only
$stmt = $pdo->prepare($sql);
$stmt->execute($args);
$bk = $stmt->fetch();
if (!$bk) { flash('Booking not found.', 'error'); header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $del = $pdo->prepare('DELETE FROM bookings WHERE booking_id = :id');
    $del->execute([':id' => $id]);
    flash('Booking for "' . $bk['customer_name'] . '" was deleted.');
    header('Location: index.php'); exit;
}
require '../includes/header.php';
?>
<h1>Delete Booking</h1>
<div class="card">
  <p>Delete the booking of <strong><?= e($bk['customer_name']) ?></strong> (<?= e($bk['event_type']) ?>, <?= e($bk['event_date']) ?>, <?= e($bk['package_name']) ?>)?</p>
  <form method="post">
    <input type="hidden" name="booking_id" value="<?= (int)$id ?>">
    <button class="btn danger" type="submit">Yes, Delete</button>
    <a class="btn ghost" href="index.php">Cancel</a>
  </form>
</div>
<?php require '../includes/footer.php'; ?>
