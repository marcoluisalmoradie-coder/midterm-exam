-- Run this ONLY if photobooth_db already exists with packages + bookings.
-- (Run it once. Select photobooth_db in phpMyAdmin first, then use the SQL tab.)
USE photobooth_db;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    address VARCHAR(150) NOT NULL,
    age INT NOT NULL,
    username VARCHAR(30) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','user') NOT NULL DEFAULT 'user',
    date_registered DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE packages
    ADD COLUMN added_by INT NULL,
    ADD COLUMN last_updated_by INT NULL,
    ADD COLUMN last_updated DATETIME NULL,
    ADD FOREIGN KEY (added_by) REFERENCES users(user_id) ON DELETE SET NULL,
    ADD FOREIGN KEY (last_updated_by) REFERENCES users(user_id) ON DELETE SET NULL;

ALTER TABLE bookings
    ADD COLUMN added_by INT NULL,
    ADD COLUMN last_updated_by INT NULL,
    ADD COLUMN last_updated DATETIME NULL,
    ADD FOREIGN KEY (added_by) REFERENCES users(user_id) ON DELETE SET NULL,
    ADD FOREIGN KEY (last_updated_by) REFERENCES users(user_id) ON DELETE SET NULL;
