<?php
require 'config/db.php';
require 'includes/auth.php';
$title = 'Login'; $base = ''; $public = true;

if (!empty($_SESSION['user'])) { header('Location: ' . (is_admin() ? 'index.php' : 'bookings/index.php')); exit; }

$username = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = :u');
    $stmt->execute([':u' => $username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'       => (int)$user['user_id'],
            'name'     => $user['first_name'] . ' ' . $user['last_name'],
            'username' => $user['username'],
            'role'     => $user['role'],
        ];
        flash('Welcome back, ' . $user['first_name'] . '!');
        header('Location: ' . ($user['role'] === 'admin' ? 'index.php' : 'bookings/index.php')); exit;
    }
    $error = 'Wrong username or password.';
}
require 'includes/header.php';
?>
<div class="auth">
  <h1>Log in</h1>
  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="form">
    <label>Username <input name="username" value="<?= e($username) ?>" required autofocus></label>
    <label>Password <input name="password" type="password" required></label>
    <div><button class="btn" type="submit">Log in</button></div>
  </form>
  <p class="switch">No account yet? <a href="register.php">Register</a></p>
</div>
<?php require 'includes/footer.php'; ?>
