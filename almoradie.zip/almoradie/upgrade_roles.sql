-- Run this ONCE if you ALREADY ran upgrade.sql before (users table exists without a role column).
USE photobooth_db;

ALTER TABLE users ADD COLUMN role ENUM('admin','user') NOT NULL DEFAULT 'user';

-- ADMIN ACCOUNT  (username: admin / password: admin123)
INSERT INTO users (first_name, last_name, address, age, username, password_hash, role)
VALUES ('System', 'Admin', 'FlashFrame HQ', 30, 'admin', '$2y$10$9HvO7/atEy7G3SAsewCnZer5208d9Ymqzkj2A886quV45tntktDoC', 'admin');
