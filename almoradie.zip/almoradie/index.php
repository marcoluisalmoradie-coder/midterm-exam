<?php
require 'config/db.php';
require 'includes/auth.php';
require_login('');
if (!is_admin()) { header('Location: bookings/index.php'); exit; }
$title = 'Dashboard'; $base = '';
require 'includes/header.php';

$totalPackages = $pdo->query('SELECT COUNT(*) FROM packages')->fetchColumn();
$totalBookings = $pdo->query('SELECT COUNT(*) FROM bookings')->fetchColumn();

$perPackage = $pdo->query(
    'SELECT p.package_id, p.package_name, p.package_price, COUNT(b.booking_id) AS total
     FROM packages p
     LEFT JOIN bookings b ON b.package_id = p.package_id
     GROUP BY p.package_id, p.package_name, p.package_price
     ORDER BY p.package_id'
)->fetchAll();
?>
<h1>Dashboard</h1>
<p class="meta">Welcome, <?= e(current_user()['name']) ?>!</p>
<div class="cards">
  <div class="card"><h3>Packages (Parent)</h3><p class="big"><?= (int)$totalPackages ?></p><a class="btn" href="packages/index.php">Manage Packages</a></div>
  <div class="card"><h3>Bookings (Child)</h3><p class="big"><?= (int)$totalBookings ?></p><a class="btn" href="bookings/index.php">Manage Bookings</a></div>
</div>

<h2>Bookings per Package <small>(one package &rarr; many bookings)</small></h2>
<table>
  <thead><tr><th>ID</th><th>Package</th><th>Price</th><th>Bookings</th></tr></thead>
  <tbody>
  <?php foreach ($perPackage as $r): ?>
    <tr><td><?= (int)$r['package_id'] ?></td><td><?= e($r['package_name']) ?></td>
        <td>&#8369;<?= number_format($r['package_price'], 2) ?></td><td><?= (int)$r['total'] ?></td></tr>
  <?php endforeach; if (!$perPackage): ?>
    <tr><td colspan="4" class="empty">No packages yet.</td></tr>
  <?php endif; ?>
  </tbody>
</table>
<?php require 'includes/footer.php'; ?>
