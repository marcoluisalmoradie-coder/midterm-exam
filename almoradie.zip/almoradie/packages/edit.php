<?php
require '../config/db.php';
require '../includes/auth.php';
require_admin('../');
$title = 'Edit Package'; $base = '../';
$id = (int)($_GET['id'] ?? $_POST['package_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM packages WHERE package_id = :id');
$stmt->execute([':id' => $id]);
$pkg = $stmt->fetch();
if (!$pkg) { flash('Package not found.', 'error'); header('Location: index.php'); exit; }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['package_name'] ?? '');
    $price = trim($_POST['package_price'] ?? '');
    $desc  = trim($_POST['package_description'] ?? '');
    $pkg['package_name'] = $name; $pkg['package_price'] = $price; $pkg['package_description'] = $desc;

    if ($name === '') $errors[] = 'Package name is required.';
    if ($price === '' || !is_numeric($price) || $price < 0) $errors[] = 'Enter a valid price.';

    if (!$errors) {
        $up = $pdo->prepare('UPDATE packages SET package_name = :n, package_price = :p, package_description = :d,
                             last_updated_by = :u, last_updated = NOW() WHERE package_id = :id');
        $up->execute([':n' => $name, ':p' => $price, ':d' => $desc, ':u' => current_user_id(), ':id' => $id]);
        flash('Package #' . $id . ' was updated.');
        header('Location: index.php'); exit;
    }
}
require '../includes/header.php';
?>
<h1>Edit Package #<?= (int)$id ?></h1>
<?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
<form method="post" class="form">
  <input type="hidden" name="package_id" value="<?= (int)$id ?>">
  <label>Package Name <input name="package_name" value="<?= e($pkg['package_name']) ?>" required></label>
  <label>Price (&#8369;) <input name="package_price" type="number" step="0.01" min="0" value="<?= e($pkg['package_price']) ?>" required></label>
  <label>Description <input name="package_description" value="<?= e($pkg['package_description']) ?>" maxlength="255"></label>
  <div><button class="btn" type="submit">Update Package</button> <a class="btn ghost" href="index.php">Cancel</a></div>
</form>
<?php require '../includes/footer.php'; ?>
