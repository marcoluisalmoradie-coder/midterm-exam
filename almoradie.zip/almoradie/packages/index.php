<?php
require '../config/db.php';
require '../includes/auth.php';
require_admin('../');
$title = 'Packages'; $base = '../';
require '../includes/header.php';
$rows = $pdo->query(
    'SELECT p.*,
            (SELECT COUNT(*) FROM bookings b WHERE b.package_id = p.package_id) AS total_bookings,
            ua.first_name AS a_first, ua.last_name AS a_last, ua.username AS a_user,
            uu.first_name AS u_first, uu.last_name AS u_last, uu.username AS u_user
     FROM packages p
     LEFT JOIN users ua ON ua.user_id = p.added_by
     LEFT JOIN users uu ON uu.user_id = p.last_updated_by
     ORDER BY p.package_id'
)->fetchAll();
?>
<div class="head"><h1>Packages <small>(Parent)</small></h1>
  <a class="btn" href="create.php">+ Add Package</a></div>
<table>
  <thead><tr><th>ID</th><th>Name</th><th>Price</th><th>Description</th><th>Bookings</th>
             <th>Added By</th><th>Last Updated By</th><th>Last Updated</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= (int)$r['package_id'] ?></td>
      <td><?= e($r['package_name']) ?></td>
      <td>&#8369;<?= number_format($r['package_price'], 2) ?></td>
      <td><?= e($r['package_description']) ?></td>
      <td><?= (int)$r['total_bookings'] ?></td>
      <td><?= who($r['a_first'], $r['a_last'], $r['a_user']) ?></td>
      <td><?= who($r['u_first'], $r['u_last'], $r['u_user']) ?></td>
      <td><?= $r['last_updated'] ? e($r['last_updated']) : '&mdash;' ?></td>
      <td class="actions">
        <a class="btn small" href="edit.php?id=<?= (int)$r['package_id'] ?>">Edit</a>
        <a class="btn small danger" href="delete.php?id=<?= (int)$r['package_id'] ?>">Delete</a>
      </td>
    </tr>
  <?php endforeach; if (!$rows): ?>
    <tr><td colspan="9" class="empty">No packages yet. Click "Add Package".</td></tr>
  <?php endif; ?>
  </tbody>
</table>
<?php require '../includes/footer.php'; ?>
