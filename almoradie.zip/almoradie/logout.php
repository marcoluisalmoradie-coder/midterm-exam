<?php
require 'includes/functions.php';  

$_SESSION = [];                   
session_regenerate_id(true);       

flash('You have been logged out.');
header('Location: login.php');
exit;
