<?php
require 'config/db.php';
$title = 'Register'; $base = ''; $public = true;

if (!empty($_SESSION['user'])) { header('Location: ' . (($_SESSION['user']['role'] ?? '') === 'admin' ? 'index.php' : 'bookings/index.php')); exit; }

$v = ['first_name' => '', 'last_name' => '', 'address' => '', 'age' => '', 'username' => ''];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) $v[$k] = trim($_POST[$k] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if ($v['first_name'] === '') $errors[] = 'First name is required.';
    if ($v['last_name'] === '')  $errors[] = 'Last name is required.';
    if ($v['address'] === '')    $errors[] = 'Address is required.';
    if (!ctype_digit($v['age']) || $v['age'] < 1 || $v['age'] > 120) $errors[] = 'Enter a valid age (1-120).';
    if (!preg_match('/^[A-Za-z0-9_]{3,30}$/', $v['username'])) $errors[] = 'Username must be 3-30 letters, numbers or underscores.';
    if (strlen($password) < 6)   $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm)  $errors[] = 'Passwords do not match.';

    if (!$errors) {
        $chk = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = :u');
        $chk->execute([':u' => $v['username']]);
        if ($chk->fetchColumn()) $errors[] = 'That username is already taken.';
    }

    if (!$errors) {
        try {
            $ins = $pdo->prepare('INSERT INTO users (first_name, last_name, address, age, username, password_hash, role)
                                  VALUES (:f, :l, :a, :g, :u, :p, \'user\')');
            $ins->execute([
                ':f' => $v['first_name'], ':l' => $v['last_name'], ':a' => $v['address'],
                ':g' => (int)$v['age'], ':u' => $v['username'],
                ':p' => password_hash($password, PASSWORD_DEFAULT),  
            ]);
            flash('Account created! You can now log in.');
            header('Location: login.php'); exit;
        } catch (PDOException $e) {
            $errors[] = 'Could not register: ' . $e->getMessage();
        }
    }
}
require 'includes/header.php';
?>
<div class="auth">
  <h1>Create an account</h1>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="form">
    <label>First Name <input name="first_name" value="<?= e($v['first_name']) ?>" required></label>
    <label>Last Name <input name="last_name" value="<?= e($v['last_name']) ?>" required></label>
    <label>Address <input name="address" value="<?= e($v['address']) ?>" required></label>
    <label>Age <input name="age" type="number" min="1" max="120" value="<?= e($v['age']) ?>" required></label>
    <label>Username <input name="username" value="<?= e($v['username']) ?>" required></label>
    <label>Password <input name="password" type="password" required></label>
    <label>Confirm Password <input name="confirm_password" type="password" required></label>
    <div><button class="btn" type="submit">Register</button></div>
  </form>
  <p class="switch">Already have an account? <a href="login.php">Log in</a></p>
</div>
<?php require 'includes/footer.php'; ?>
